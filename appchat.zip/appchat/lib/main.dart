import 'package:appchat/screen/registerscreen.dart';
import 'package:appchat/screen/chatscreen.dart';
import 'package:appchat/screen/signin.dart';
import 'package:appchat/screen/splachscreen.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async{
  //beacuse it futer we need to write async =await
 WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: splachScreen(),
      routes:{
        'splach':(context)=>splachScreen(),
        'signin':(context)=>signin(),
        'signup':(context)=>Regsterscreen(),
        'chat':(context)=>chat(),
      },
    );
  }
}
