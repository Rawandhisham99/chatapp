import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import'package:cloud_firestore/cloud_firestore.dart';

final _firestor=FirebaseFirestore.instance;
late User signedInUser;
class chat extends StatefulWidget {
  const chat({Key? key}) : super(key: key);

  @override
  State<chat> createState() => _chatState();
}

class _chatState extends State<chat> {
  final meescontrollar=TextEditingController();
  final _auth=FirebaseAuth.instance;

  String? meesgetext;//textwrite it
  String? sender;
  @override
  void initState(){
    super.initState();
    currentuser();
  }
  //يوزر سجل دخول ؟؟
  void currentuser(){
    try{ final user=_auth.currentUser;
      if(user !=null){
        signedInUser=user;
      }
    }catch (e){}

  }//check the user login or not
  //راح تسحب البيانات من فايرستور

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title: Card(child: Row(children: [
          Image.asset('assets/chat.png',height: 40,),
          SizedBox(width: 10,),
          Text('MessageMe',style: TextStyle(color: Color(0xff2e386b)),)
          ,
        ],)
          ,),actions: [IconButton(onPressed: (){
        _auth.signOut();
        Navigator.pop(context);
      }, icon:Icon(Icons.logout))],
      ),
      body:SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            MessagesStream(),
            Container(
          decoration: BoxDecoration(
            border: Border(top:BorderSide(
              color: Colors.lightBlueAccent,
              width: 3,
            )
            )
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [Expanded(
                child:TextField(controller: meescontrollar,
            onChanged: (value){
              meesgetext=value;
            },
            decoration: InputDecoration(
              contentPadding: EdgeInsets.symmetric(
                vertical: 10,
                  horizontal: 20 ),
              hintText: 'Write Your Massege here..  :)',border:InputBorder.none

            ),
          )
            ),
              TextButton(onPressed: (){
                meescontrollar.clear();
                _firestor.collection('messge').add({ 'sender':sender,
                'text':meesgetext
              }); //ربطت فايرستور مع تطبيق
            }, child:Text('send',style: TextStyle(color:Colors.lightBlue,fontSize: 18,fontWeight: FontWeight.bold),))
            ],),
        )],),
      ),
    );
  }
}
class MessagesStream extends StatelessWidget {
  const MessagesStream({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(stream:_firestor.collection('messgee').snapshots() ,
        builder:(context ,snapshot){
          List<messagline>messagewidgets=[];
          if(!snapshot.hasData){
            return Center(child: Text('NO data here'),);
          }
          final messag=snapshot.data!.docs;
          for(var mess in messag){
            final  messagText=mess.get('text');
            final  messgesender=mess.get('sender');
            final currentUser=signedInUser.email;

            final messagewidget=messagline(text:messagText,Sender:messgesender,
            IsMe:currentUser==messgesender ,);
            messagewidgets.add(messagewidget);
          }
          return Expanded(
              child: ListView(
                padding: EdgeInsets.symmetric(horizontal: 10,vertical: 20),
                children:messagewidgets,));
        } );
  }
}


class messagline extends StatelessWidget {
  const messagline({this.text,required this.IsMe ,this.Sender}) ;
  final String? text;
  final String? Sender;
  final bool IsMe;
  @override
  Widget build(BuildContext context) {
    return Column(
       crossAxisAlignment:IsMe? CrossAxisAlignment.end: CrossAxisAlignment.start

      ,
      children: [
        Text('$Sender',style: TextStyle(fontSize: 12,color:Colors.black26),),
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: Material(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(30),
              bottomLeft: Radius.circular(30),
              bottomRight: Radius.circular(30)
            ),
            color:IsMe?Colors.blue:Colors.white,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10.0,horizontal: 20.0),
              child: Text('$text',
                style: TextStyle(fontSize: 20,color: Colors.black),),
            ),
          ),
        ),
      ],
    ) ;
  }
}

