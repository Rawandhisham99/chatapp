import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
class Regsterscreen extends StatefulWidget {
  const Regsterscreen({Key? key}) : super(key: key);

  @override
  State<Regsterscreen> createState() => _RegsterscreenState();
}

class _RegsterscreenState extends State<Regsterscreen> {
  final _auth=FirebaseAuth.instance;//انشئت هذا متغير يضل ثابت للمستفبل وبقدر استخدمه لتسجيل المستخدمين 
  final  _formkey=GlobalKey<FormState>();
  String? _emaill;
  String? _pass;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:Colors.white,
      body:
      Form(
        key: _formkey,
        child:SingleChildScrollView(child:
      Container( margin:EdgeInsets.only(top: 150),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [Container(height: 150,child: Image.asset('assets/chat.png'),
            ),SizedBox(height:4,),
              TextFormField(
                  onChanged: (value)=>_emaill=value,
                  keyboardType: TextInputType.emailAddress,
                  validator: (value)
                  {if(value!.isEmpty){
                    print("object");
                  }},
                decoration: InputDecoration(labelText: 'Enter your Email',
                contentPadding: EdgeInsets.symmetric(vertical: 10,horizontal: 20),
                border: OutlineInputBorder(borderRadius:BorderRadius.all(Radius.circular(10))
                ),enabledBorder:OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey),
                    borderRadius:BorderRadius.all(Radius.circular(10)) ,),
                  focusedBorder:OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.blue),
                  borderRadius:BorderRadius.all(Radius.circular(10)) ,
                ),
              )
              ),SizedBox(height:7,),
              TextFormField(
                  onChanged: (value)=>_pass=value,
                  validator: (value)=>value!.length<6?'Enter your long':null,
                  decoration: InputDecoration(labelText: 'Enter your Password',
                    contentPadding: EdgeInsets.symmetric(vertical: 10,horizontal: 20),
                    border: OutlineInputBorder(borderRadius:BorderRadius.all(Radius.circular(10))
                    ),enabledBorder:OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey),
                      borderRadius:BorderRadius.all(Radius.circular(10)) ,),
                    focusedBorder:OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blue),
                      borderRadius:BorderRadius.all(Radius.circular(10)) ,
                    ),
                  ),obscureText:true
              ),
              SizedBox(height:4,),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Material(
                  elevation: 5,
                  color: Colors.lightBlueAccent,
                  borderRadius: BorderRadius.circular(10),
                  child: MaterialButton(
                    onPressed:()async{
                        if(_formkey.currentState!.validate()){
                          final newuser=await _auth.createUserWithEmailAndPassword(email: _emaill!, password: _pass!);


                         Navigator.of(context).pushReplacementNamed('chat');
                      }
                    },
                    minWidth: 200,
                    height: 42,
                    child: Text('Sign up' ,style: TextStyle(color:Colors.black,fontSize: 20),),
                  ),
                ),
              )

            ],
          ),
        ),
      ),))

    );
  }
}
