import 'package:flutter/material.dart';


class splachScreen extends StatefulWidget {
  
  const splachScreen({Key? key}) : super(key: key);

  @override
  State<splachScreen> createState() => _splachScreenState();
}

class _splachScreenState extends State<splachScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold( backgroundColor: Colors.white,
      body:Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment:CrossAxisAlignment.stretch
          ,children: [
            Column(children: [Container(height: 180,child:Image.asset('assets/chat.png'),),
            Text('MassegMe',
              style:TextStyle(fontSize: 30,fontWeight: FontWeight.w900,color: Color(0xff2e386b)),)],),
          SizedBox(height: 15,),
          Padding(
        padding: const EdgeInsets.all(8.0),
        child: Material(
          elevation: 5,
          color: Colors.lightBlueAccent,
          borderRadius: BorderRadius.circular(10),
          child: MaterialButton(
            onPressed:(){


              Navigator.of(context).pushNamed('signin');
            },
            minWidth: 200,
            height: 42,
            child: Text('Sign in' ,style: TextStyle(color:Colors.black,fontSize: 20),),
          ),
        ),
      ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Material(
              elevation: 5,
              color: Colors.lightBlueAccent,
              borderRadius: BorderRadius.circular(10),
              child: MaterialButton(
                onPressed:(){
                  Navigator.of(context).pushNamed('signup');

                },
                minWidth: 200,
                height: 42,
                child: Text('Sign up' ,style: TextStyle(color:Colors.black,fontSize: 20),),
              ),
            ),
          )

        ],
        ),

      ),

    );
  }
}
//انشئت هذا الكلاس علشان ههستخدمو اكتر من مرة
